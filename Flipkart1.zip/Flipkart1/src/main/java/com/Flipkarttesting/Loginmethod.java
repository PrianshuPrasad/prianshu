package com.Flipkarttesting;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

public class Loginmethod extends basedriver {

	public WebDriver driver;

//		Login method for login user
		public void login(WebDriver driver) throws IOException, InterruptedException {
		Login lg = new Login(driver);
		lg.addtocartlogin().click();
//		lg.validation().getText().equalsIgnoreCase("");
//
//		asser().assertEquals("Enter your email or mobile phone number", lg.validation().getText());
//		Reporter.log("Validation message displayed", true);
		loadProperty();
//	    lg.mobilenumber().click();
		lg.mobilenumber().sendKeys(prop.getProperty("mobilenumber"));
		lg.password().sendKeys(prop.getProperty("password"));
		lg.loginbutton().click();
		
//		asser().assertEquals("Hello, mohit", lg.loginassert().getText());
	}

	
}
